import java.util.*;
import static java.lang.System.out;
public class Lab3_7_Str_anotherStr {
  public static void main(String args[]) {
      String str1 = "Hey akram";
      String str2 = "Hey Bhdflkhram";
      //String str3 = "Integers are not immutable";
      
      int result = str1.compareTo( str2 );
      System.out.println(result);
      
//      result = str2.compareTo( str3 );
//      System.out.println(result);
//      
//      result = str3.compareTo( str1 );
//      System.out.println(result);
   }
}
