import java.util.*;
import static java.lang.System.out;
public class Lab3_4 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    int a[] =new int [26];
    for (int i=0; i<s.length();i++) {
      int n=(int)s.charAt(i)-65;
      ++a[n];
    }
    for (int i=0;i<a.length;i++) {
      out.println((char)(i+65)+" which is "+(i+65)+" was found "+a[i]+" times");
    }
  }
}
      