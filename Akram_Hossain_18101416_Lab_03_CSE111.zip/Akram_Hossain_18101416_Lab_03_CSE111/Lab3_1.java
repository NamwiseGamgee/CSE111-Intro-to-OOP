import java.util.*;
import static java.lang.System.out;
public class Lab3_1 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    out.println(s.length());
  }
}