import java.util.*;
import static java.lang.System.out;
public class Lab3_6 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    String b="==THE END==";
  for (int i=0;i<3;i++) {
      if (i==1) {
       out.println(s.concat(b));
      }
      else {
        out.println(s);
      }
    }
  }
}