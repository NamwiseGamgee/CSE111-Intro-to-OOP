import java.util.*;
import static java.lang.System.out;
public class Lab3_2 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
    for (int i=0;i<s.length();i++) {
      out.println(s.charAt(i));
    }
  }
}