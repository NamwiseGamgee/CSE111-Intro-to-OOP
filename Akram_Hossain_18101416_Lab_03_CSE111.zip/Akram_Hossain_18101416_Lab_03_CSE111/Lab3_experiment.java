import java.util.*;
import static java.lang.System.out;
public class Lab3_experiment {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    char[] helloArray = { 'h', 'e', 'l', 'l', 'o', '.' };
String helloString = new String(helloArray);
out.println(helloString);
  }
}