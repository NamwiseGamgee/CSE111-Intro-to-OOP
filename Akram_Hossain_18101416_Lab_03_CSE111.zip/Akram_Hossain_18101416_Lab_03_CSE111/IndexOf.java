import java.io.*;
public class IndexOf {

   public static void main(String args[]) {
      String Str = new String("Welcome to Tutorialspoint.com");
      System.out.print("Found Index :" );
      System.out.println(Str.indexOf( 'o' ));
   }
}