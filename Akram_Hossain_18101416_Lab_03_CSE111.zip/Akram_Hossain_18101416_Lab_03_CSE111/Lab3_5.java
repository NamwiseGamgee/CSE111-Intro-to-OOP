import java.util.*;
import static java.lang.System.out;
public class Lab3_5 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    String s=sc.nextLine();
  for (int i=0;i<3;i++) {
      if (i==1) {
       out.println(s+"==THE END==");
      }
      else {
        out.println(s);
      }
    }
  }
}