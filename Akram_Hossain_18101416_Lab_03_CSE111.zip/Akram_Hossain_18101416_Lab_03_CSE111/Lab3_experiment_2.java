import java.util.*;
import static java.lang.System.out;
public class Lab3_experiment_2 {
  public static void main (String[] args) {
    Scanner sc=new Scanner(System.in);
    char [] c=new char[5];
    out.print((int)c[2]);
  }
}