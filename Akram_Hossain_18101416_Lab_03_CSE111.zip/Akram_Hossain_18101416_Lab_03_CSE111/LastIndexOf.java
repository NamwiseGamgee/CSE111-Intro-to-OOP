import java.io.*;
public class LastIndexOf {

   public static void main(String args[]) {
      String Str = new String("Welcome to Tutorialspoint.com");
      System.out.print("Found Last Index :" );
      System.out.println(Str.lastIndexOf( 'o' ));
   }
}